<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shorturl_model extends CI_Model {

    public function create_short_url($long_url) {
        // Generate a unique short code
        $short_code = substr(md5(time()), 0, 6);

        // Save in the database
        $data = ['long_url' => $long_url, 'short_code' => $short_code];
        $this->db->insert('short_urls', $data);

        return $short_code;
    }

    public function get_long_url($short_code) {
        $query = $this->db->get_where('short_urls', ['short_code' => $short_code]);
        return $query->row_array();
    }
}
