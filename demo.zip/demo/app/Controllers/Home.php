<?php

namespace App\Controllers;
use CodeIgniter\Controller;

class Home extends BaseController
{
    public function index()
    { 
   return view('urldemo');

    } 
	 public function encode()
    {  
  $response = service('response'); 

 $data = json_decode(file_get_contents("php://input"), true);
   $posturl=$data["long_url"];

// Retrieve existing cookie data
$existingData = $this->request->getCookie('encodedata');

if ($existingData) { 
    // Decode the stored JSON data into an array
    $urldataobject = json_decode($existingData, true);
    
    // Ensure it's an array (in case it's corrupted or empty)
    if (!is_array($urldataobject)) {
        $urldataobject = array();
    }
} else {
    $urldataobject = array();
}

// Generate a unique short URL
$short_code = "www.demo.com/" . substr(md5($posturl), 0, rand(6, 6));

// Store the new shortened URL in the array
$urldataobject[$short_code] = $posturl;

// Encode array as JSON before storing it in a cookie
$response->setCookie('encodedata', json_encode($urldataobject), 3600);

 $data = [
          
			 'short_url'=>$short_code
           
        ];
		echo json_encode($data);

    }  

   public function decode()
    {   
	
      //$long_url = $this->request->getPost('short_url');
 $data = json_decode(file_get_contents("php://input"), true);
   $long_url=$data["short_url"];

	  $response = service('response'); 
      $dataobject=json_decode($this->request->getCookie('encodedata'),true); 

      if ($this->request->getCookie('encodedata')) {
	     if (array_key_exists($long_url, $dataobject)) {
			 $data=$dataobject[$long_url];
		 }else
		 {
			$data="record not found"; 
			 
		 }
		 
	  }else
	  {
		$data="record not found";   
		  
	  } 
	  
	   $dataobject = [
           
			 'long_url'=>$data
           
        ];
		echo json_encode($dataobject);
	}	
    	
	
	
	
}
