<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UrlShortener extends CI_Controller {

    private $tinurl_api_key = 'YOUR_TINURL_API_KEY'; // Replace with your TinURL API key

    public function shorten() {
        $long_url = $this->input->post('long_url');

        if (!$long_url) {
            echo json_encode(['error' => 'URL required']);
            return;
        }

        $short_url = $this->tinurl_shorten($long_url);
        echo json_encode(['short_url' => $short_url]);
    }

    private function tinurl_shorten($long_url) {
        $api_url = "https://tinurl.com/api/shorten";
        $post_data = [
            "api_key" => $this->tinurl_api_key,
            "url" => $long_url
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data['short_url'] ?? 'Error shortening URL';
    }
}
