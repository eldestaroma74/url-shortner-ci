<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('/encode', 'Home::encode'); // For POST requests

$routes->post('/decode', 'Home::decode'); // For POST requests

